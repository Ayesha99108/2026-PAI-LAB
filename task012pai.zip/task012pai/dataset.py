qa_data = [
    {"question": "Where is the library?", "answer": "Library is in Block C, open 8 AM to 10 PM."},
    {"question": "Where is cafeteria?", "answer": "Cafeteria is near the main gate."},
    {"question": "Where are labs located?", "answer": "Labs are in Block B and Block C."},
    {"question": "Where is hostel?", "answer": "Hostel is on west side of campus."},
    {"question": "Where is sports ground?", "answer": "Sports ground is behind academic block."},
    {"question": "What are library timings?", "answer": "Library is open from 8 AM to 10 PM."},
]