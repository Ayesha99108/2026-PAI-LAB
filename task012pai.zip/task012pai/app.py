from flask import Flask, render_template, request, jsonify
from faiss_index import search

app = Flask(__name__)

# 💬 Handle small talk separately
def handle_basic_inputs(text):
    text = text.lower()

    if text in ["hi", "hello", "hey"]:
        return "👋 Hello! Ask me about library, hostel, labs, cafeteria or sports."

    if text in ["ok", "okay"]:
        return "👍 Got it! Ask me anything about campus."

    return None


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    user_input = data.get("message")

    # 🔥 Step 1: basic chat handling
    basic = handle_basic_inputs(user_input)
    if basic:
        return jsonify({"reply": basic})

    # 🔥 Step 2: FAISS search
    response = search(user_input)

    return jsonify({"reply": response})


if __name__ == "__main__":
    app.run(debug=True)