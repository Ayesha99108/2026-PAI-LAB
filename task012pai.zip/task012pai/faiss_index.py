import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
from dataset import qa_data

# Load model (MiniLM)
model = SentenceTransformer("all-MiniLM-L6-v2")

questions = [item["question"] for item in qa_data]
answers = [item["answer"] for item in qa_data]

# Create embeddings
embeddings = model.encode(questions)

# Convert to numpy
embeddings = np.array(embeddings).astype("float32")

dimension = embeddings.shape[1]

# FAISS index
index = faiss.IndexFlatL2(dimension)
index.add(embeddings)


def search(query):
    query_vec = model.encode([query])
    query_vec = np.array(query_vec).astype("float32")

    D, I = index.search(query_vec, k=1)

    distance = D[0][0]   # similarity score
    best_index = I[0][0]

    # 🚨 IMPORTANT FIX: prevent wrong answers
    if distance > 1.2:   # threshold (tune if needed)
        return "❌ I am not sure. Please ask about library, hostel, labs, cafeteria, sports."

    return answers[best_index]