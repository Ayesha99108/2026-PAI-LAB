from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

def get_response(bot, user_input):
    text = user_input.lower()

    if bot == "campus":

        if any(word in text for word in ["hi", "hello", "start", "tour"]):
            return (
                "👋 Welcome to your virtual campus tour!\n"
                "You can ask me:\n"
                "➡ Take me to library\n"
                "➡ Show cafeteria\n"
                "➡ Guide me to labs\n"
                "➡ Hostel location\n"
                "➡ Sports ground\n"
            )

        elif "library" in text:
            return (
                "📚 Library Tour:\n"
                "Step 1: Main Gate 🚪\n"
                "Step 2: Pass Admin Block\n"
                "Step 3: Turn right at Block B\n"
                "📍 Library is big glass building"
            )

        elif "cafeteria" in text or "canteen" in text:
            return (
                "🍔 Cafeteria Guide:\n"
                "Near central courtyard\n"
                "Open 9 AM - 6 PM"
            )

        elif "lab" in text:
            return (
                "💻 Labs:\n"
                "CS → Block B\n"
                "AI → Block C\n"
                "Physics → Block D"
            )

        elif "hostel" in text:
            return (
                "🏠 Hostel:\n"
                "West side of campus\n"
                "24/7 security"
            )

        elif "sports" in text:
            return (
                "🏃 Sports Ground:\n"
                "Behind academic block"
            )

        elif "auditorium" in text:
            return (
                "🎤 Auditorium:\n"
                "Near Admin Block"
            )

        else:
            return "Ask about library, cafeteria, labs, hostel, sports."

    return "Please select Campus Bot"


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    msg = data.get("message")
    bot = data.get("bot")

    reply = get_response(bot, msg)
    return jsonify({"reply": reply})


if __name__ == "__main__":
    app.run(debug=True)