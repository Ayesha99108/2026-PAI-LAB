from flask import Flask, render_template, jsonify
import requests

app = Flask(__name__)

API_KEY = "1E9lhMKFErMmJnM3ZoT26a58tnIBIfAvlHGVxfQi"
URL = f"https://api.nasa.gov/planetary/apod?api_key={API_KEY}"

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get_apod")
def get_apod():
    response = requests.get(URL)
    data = response.json()

    return jsonify({
        "title": data.get("title"),
        "explanation": data.get("explanation"),
        "url": data.get("url"),
        "media_type": data.get("media_type"),
        "date": data.get("date")
    })

if __name__ == "__main__":
    app.run(debug=True)